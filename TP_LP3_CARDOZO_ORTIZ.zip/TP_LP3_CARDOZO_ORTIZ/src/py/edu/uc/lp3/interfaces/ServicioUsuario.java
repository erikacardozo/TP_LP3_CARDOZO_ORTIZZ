package py.edu.uc.lp3.interfaces;

import java.util.ArrayList;

import py.edu.uc.lp3.clases.usuario;

public interface ServicioUsuario {
	public usuario crear_usuario(usuario nuevo_usuario);
	public ArrayList<Integer> listar_usuario(Integer IDuser);
	public ArrayList<Integer> listar_usuario(String rol);
	public usuario actualizar_usuario(usuario ci);
	public void eliminar_usuario(int IDuser);
	
}
