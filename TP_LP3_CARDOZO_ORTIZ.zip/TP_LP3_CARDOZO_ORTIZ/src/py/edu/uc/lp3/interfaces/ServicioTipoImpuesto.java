package py.edu.uc.lp3.interfaces;

public interface ServicioTipoImpuesto {
//ver pq capaz debe ser clase y yo quise poner como atributo de mercaderia
}
